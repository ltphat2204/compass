import {test,expect} from '@playwright/test';
import {unchanged,pending,failed} from './outcomes.mjs';
const tasksUrl='**/api/tasks';
const titleInput=page=>page.getByRole('textbox').first();
const addButton=page=>page.getByRole('button',{name:/^Thêm(?: công việc)?$/i});
async function filter(page,name) {
  const control=page.getByRole('button',{name}).or(page.getByRole('tab',{name})).or(page.getByRole('radio',{name})).or(page.getByRole('link',{name}));
  if(await control.count())return control.click();
  const select=page.getByRole('combobox'); const options=await select.locator('option').evaluateAll(options=>options.map(o=>({value:o.value,text:o.textContent})));
  const option=options.find(o=>name.test(o.text.trim())); expect(option).toBeTruthy(); await select.selectOption(option.value);
}
async function reset(request) {
  const response=await request.get('/api/tasks'); expect(response.status()).toBe(200);
  for(const task of (await response.json()).tasks) expect((await request.delete(`/api/tasks/${encodeURIComponent(task.id)}`)).status()).toBe(204);
}
async function add(page,title) { await titleInput(page).fill(title); await addButton(page).click(); await expect(page.getByText(title,{exact:true})).toBeVisible(); }
function row(page,title) {
  // The narrowest semantic container containing both the task text and its edit action.
  return page.getByText(title,{exact:true}).locator('xpath=ancestor::*[.//button[normalize-space()="Sửa"]][1]');
}
async function list(request) {const r=await request.get('/api/tasks'); expect(r.status()).toBe(200); return (await r.json()).tasks;}
test.beforeEach(async({request})=>reset(request));
test('AC-01/06 complete CRUD, cancellation, filters, fresh reload without localStorage',async({page,request})=>{
  await page.addInitScript(()=>{Storage.prototype.setItem=function(){throw new Error('Task storage must use the server');};});
  await page.goto('/');
  await expect(page.getByRole('heading').first()).toBeVisible();
  await expect(page.getByText(/chưa có công việc|danh sách trống|không có công việc/i)).toBeVisible();
  const emptyText=(await page.getByText(/chưa có công việc|danh sách trống|không có công việc/i).first().textContent()).trim();
  await add(page,'Mua sữa'); await expect(titleInput(page)).toHaveValue(''); const beforeCancel=await list(request);
  const item=row(page,'Mua sữa'); await item.getByRole('button',{name:/^Sửa$/i}).click();
  const edit=page.getByRole('textbox').last(); await edit.fill('Bỏ thay đổi'); await page.getByRole('button',{name:/^Hủy$/i}).click();
  await expect(page.getByText('Mua sữa',{exact:true})).toBeVisible(); unchanged(await list(request),beforeCancel);
  await item.getByRole('button',{name:/^Sửa$/i}).click(); await edit.fill('Đọc sách'); await page.getByRole('button',{name:/^Lưu$/i}).click();
  await expect(page.getByText('Đọc sách',{exact:true})).toBeVisible();
  await filter(page,/^Chưa hoàn thành$/i); await row(page,'Đọc sách').getByRole('checkbox').check();
  await expect(page.getByText('Đọc sách',{exact:true})).toHaveCount(0);
  const filteredMessage=page.getByText(/không có|chưa có|trống/i).filter({hasNot:page.getByRole('button')}).first();
  await expect(filteredMessage).toBeVisible(); expect((await filteredMessage.textContent()).trim()).not.toBe(emptyText);
  await filter(page,/^Đã hoàn thành$/i); await expect(page.getByText('Đọc sách',{exact:true})).toBeVisible();
  await row(page,'Đọc sách').getByRole('checkbox').uncheck(); await expect(page.getByText('Đọc sách',{exact:true})).toHaveCount(0);
  await filter(page,/^Tất cả$/i);
  await page.reload(); await expect(page.getByText('Đọc sách',{exact:true})).toBeVisible();
  const beforeDeleteCancel=await list(request); page.once('dialog',dialog=>dialog.dismiss());
  const deletion=row(page,'Đọc sách').getByRole('button',{name:/^Xóa$/i}); await deletion.click(); page.removeAllListeners('dialog');
  const confirmation=page.getByRole('dialog').or(page.getByRole('alertdialog'));
  if(await confirmation.count()) await confirmation.getByRole('button',{name:/hủy|không/i}).click();
  await expect(page.getByText('Đọc sách',{exact:true})).toBeVisible(); unchanged(await list(request),beforeDeleteCancel);
  page.once('dialog',dialog=>dialog.accept()); await deletion.click(); page.removeAllListeners('dialog');
  if(await confirmation.count()) await confirmation.getByRole('button',{name:/xóa|xác nhận|đồng ý/i}).click();
  await expect(page.getByText('Đọc sách',{exact:true})).toHaveCount(0); expect(await list(request)).toHaveLength(0);
});
test('AC-05 loading, GET error and retry',async({page})=>{
  let release; const gate=new Promise(r=>release=r); let fail=true;
  await page.route(tasksUrl,async route=>{await gate;if(fail)await route.fulfill({status:500,json:{error:{code:'STORAGE_ERROR',message:'Không thể tải công việc'}}});else await route.continue();});
  await page.goto('/'); await expect(page.getByText(/đang tải/i)).toBeVisible(); release();
  const retry=page.getByRole('button',{name:/thử lại|tải lại/i}); await expect(retry).toBeVisible(); fail=false; await retry.click();
  await expect(page.getByText(/chưa có công việc|danh sách trống|không có công việc/i)).toBeVisible();
});
for(const failure of ['400','404','500','connection','lost-response']) test(`AC-05 mutation ${failure}, no automatic retries and no false state`,async({page,request})=>{
  await page.goto('/'); await expect(addButton(page)).toBeVisible();
  let calls=0, release; const gate=new Promise(r=>release=r);
  await page.route(tasksUrl,async route=>{
    if(route.request().method()!=='POST')return route.continue();
    calls++; await gate;
    if(failure==='lost-response'){await route.fetch();return route.abort('connectionreset');}
    if(failure==='connection')return route.abort('connectionreset');
    return route.fulfill({status:Number(failure),json:{error:{code:`E${failure}`,message:'Không thể lưu công việc'}}});
  });
  await titleInput(page).fill('Giữ nội dung'); await addButton(page).click(); await expect(addButton(page)).toBeDisabled();
  await expect(page.getByText('Giữ nội dung',{exact:true})).toHaveCount(0); release();
  await expect(addButton(page)).toBeEnabled(); await expect(titleInput(page)).toHaveValue('Giữ nội dung');
  await expect(page.getByText('Giữ nội dung',{exact:true})).toHaveCount(0);
  if(failure==='404')await expect(page.getByText(/tải lại/i).first()).toBeVisible();
  else await expect.poll(async()=>{
    const announced=page.getByRole('alert').or(page.getByRole('status')).filter({hasText:/không|lỗi|thất bại|kết nối/i});
    if(await announced.count())return announced.first().isVisible();
    return titleInput(page).evaluate(e=>(e.getAttribute('aria-describedby')||'').split(/\s+/).some(id=>{const message=document.getElementById(id);return message && message.getClientRects().length && /không|lỗi|thất bại|kết nối/i.test(message.textContent);}));
  }).toBe(true);
  await page.waitForTimeout(1200); expect(calls).toBe(1);
  expect((await list(request)).length).toBe(failure==='lost-response'?1:0);
  await page.unroute(tasksUrl); await page.reload();
  if(failure==='lost-response')await expect(page.getByText('Giữ nội dung',{exact:true})).toBeVisible();
});
for(const operation of ['edit','delete','complete'])test(`AC-05 ${operation} pending lock, no optimism, failed state and no retry`,async({page,request})=>{
  await page.goto('/'); await add(page,'Giữ công việc'); const persisted=await list(request);
  let release,calls=0; const gate=new Promise(resolve=>release=resolve);
  await page.route('**/api/tasks/*',async route=>{
    if(!['PATCH','DELETE'].includes(route.request().method()))return route.continue();
    calls++; await gate; await route.fulfill({status:500,json:{error:{code:'STORAGE_ERROR',message:'Không thể lưu công việc'}}});
  });
  const item=row(page,'Giữ công việc');let sender,confirm;
  if(operation==='edit') {
    await item.getByRole('button',{name:/^Sửa$/i}).click();await page.getByRole('textbox').last().fill('Bản sửa chưa lưu');sender=page.getByRole('button',{name:/^Lưu$/i});
  } else sender=operation==='complete'?item.getByRole('checkbox'):item.getByRole('button',{name:/^Xóa$/i});
  const observe=async()=>{
    const checkbox=page.getByRole('checkbox').first();
    return {visible:await page.getByText('Giữ công việc',{exact:true}).isVisible(),checked:await checkbox.count()?await checkbox.isChecked():undefined,replacement:await page.getByText('Bản sửa chưa lưu',{exact:true}).isVisible()};
  };
  const before=await observe();
  if(operation==='delete')page.once('dialog',dialog=>dialog.accept());
  await sender.click(); page.removeAllListeners('dialog');
  if(operation==='delete') {
    const dialog=page.getByRole('dialog').or(page.getByRole('alertdialog'));
    if(await dialog.count()){confirm=dialog.getByRole('button',{name:/xóa|xác nhận|đồng ý/i});await confirm.click();}
  }
  const disabled=async()=>await sender.isDisabled()||(confirm&&await confirm.count()?await confirm.isDisabled():false);
  try {
    await expect.poll(disabled).toBe(true);pending({disabled:await disabled(),view:await observe()},before);
    unchanged(await list(request),persisted);
  } finally {release();}
  await expect.poll(disabled).toBe(false);
  if(operation==='edit')await expect(page.getByRole('textbox').last()).toHaveValue('Bản sửa chưa lưu');
  await page.waitForTimeout(1200);
  failed({view:await observe(),calls,input:operation==='edit'?await page.getByRole('textbox').last().inputValue():undefined},before,operation==='edit'?'Bản sửa chưa lưu':undefined);
  unchanged(await list(request),persisted);
});
test('AC-07 labels, keyboard focus, safe text and responsive widths',async({page})=>{
  await page.goto('/'); const input=titleInput(page); await expect(input).toHaveAccessibleName(/.+/);
  const beforeFocus=await addButton(page).evaluate(e=>{const s=getComputedStyle(e);return [s.backgroundColor,s.borderColor,s.color,s.boxShadow,s.outline];});
  await input.focus(); await input.fill('<img src=x onerror="window.__unsafe=1">'); await page.keyboard.press('Tab');
  const focus=await page.evaluate(()=>{const e=document.activeElement,s=getComputedStyle(e);return {tag:e.tagName,outline:s.outlineStyle!=='none'&&parseFloat(s.outlineWidth)>0,styles:[s.backgroundColor,s.borderColor,s.color,s.boxShadow,s.outline]};});
  expect(focus.tag).not.toBe('BODY'); expect(focus.outline||JSON.stringify(focus.styles)!==JSON.stringify(beforeFocus)).toBe(true);
  await addButton(page).focus(); await page.keyboard.press('Enter');
  await expect(page.getByText('<img src=x onerror="window.__unsafe=1">',{exact:true})).toBeVisible(); expect(await page.evaluate(()=>window.__unsafe)).toBeUndefined();
  await add(page,'😀'.repeat(200));
  for(const width of [360,1280]) {await page.setViewportSize({width,height:800}); expect(await page.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth)).toBe(true); await expect(addButton(page)).toBeVisible();}
});
